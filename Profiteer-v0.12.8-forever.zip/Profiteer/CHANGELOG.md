# Changelog

## 0.12.8
- Crafts: Ctrl+right-click a row to remove its profession from a crafter who no longer has it (it asks for each crafter on the row). The automatic clean-up of dropped professions still only runs for the character you are logged in on.

## 0.12.7
- After a full scan is refused because the game limits them, the status line now counts down to the next scan you are allowed to run.

## 0.12.6
- Shopping lists: the Fish list is now "Fish and cooking" and also has the common cooking ingredients (meats and spices), so you can price check them from the same list.

## 0.12.5
- Shopping lists: the ready-made lists are grouped by what goes together. "Herbs and alchemy" now has the herbs plus vials and the elemental reagents, "Ores, stone and bars" has ores, stone and the bars, and "Cloth, leather and hides" has all the cloth, bolts and leather. Gems, Enchanting materials and Fish stay as they were.

## 0.12.4
- Fix: a character who dropped a profession is no longer listed as a crafter for it. Profiteer now compares each character's saved recipes with the professions they have, and removes the ones they no longer have (it tells you in chat when it does).

## 0.12.3
- Fix: a chat line whose text the game hides (it happens in some places, like dungeons) no longer causes a selling-window error.

## 0.12.2
- Fix: a character with a first and last name (like Dr Flamel) was also listed under just the first word ("Dr"), so the Crafters column showed things like "Dr, Dr Hatchet". The two entries are now merged into the real name.

## 0.12.1
- Items that are not listed at the last scan (armor, weapons and other one-offs) now show their last seen price in the tooltip, kept for 60 days. It is stored apart from the scan prices, so profit figures are unaffected.

## 0.12.0
- Auction scan: when the server does not answer a full scan, the message now says about how many minutes until the next one is allowed.
- A craft you learn now moves into your learned crafts right away (also when learned from a trainer or recipe), without reopening the profession window.
- Shopping > Crafts now lists every craft of every profession from a built-in catalog, not just recipes you have opened.
- Shopping tab: a new Crafts drop-down lists every craft of every profession, each profession in its own section (click to open), with a search box. Click a craft to put its materials on the shopping list. It shows all crafts whatever the Crafts tab filters are set to; ones with no AH price are grey.
- Crafts tab: the bottom row is tidier. The status line no longer sits tight against the window edge, and the search box no longer overlaps the Live prices button.

## 0.11.1
- Fonts: the font pack now ships inside this add-on (Fonts folder), so the separate Look Fonts add-on is no longer needed, and there are about 60 more fonts to pick from under Look > Font.

## 0.11.0
- Fix: Shopping tab no longer sticks on "Buying...". It now says "Not enough gold" when the price is more than you carry, and gives up with a message if the auction house never answers.
- New: **Live prices** button on the Crafts tab. With the auction house open, it searches each item on the current page (the crafts shown plus their materials) one at a time, the same search the Shopping tab uses, and updates their prices to what is listed right now. Much faster than a full scan and more accurate. Click again to stop. Up to 60 items at a time.

## 0.10.0
- Prices and characters are now kept separately for each realm, so a PvP realm and a PvE realm never mix. Auction House prices, price history, listings, characters, recipes, inventory, your listed auctions, the sales ledger and gold worth are all per realm. Settings, the look, item names and vendor prices stay shared. The window title shows PvE or PvP.
- Existing data moves to the realm you used most; other realms start fresh and fill in the first time you open the auction house there.

## 0.9.1
- New: sale sound options (Kaching), scan diagnostics and sender tracing, two-part character name fix, /issues log.

## 0.9.0
- Auction House: the Auctions page header no longer runs off the window; tab contents scale with a new slider (smaller by default) so lists fit; the Cancelling tab shows more (gap to the lowest price, relist price, total).
- Recipe tracker: a recipe item's tooltip (Recipe, Pattern, Formula, Plans...) lists which of your characters already know it, which could still learn it, and which have no such profession. Names are saved whenever a profession window opens (enchants included), and a recipe you learn from an item is marked right away. Open each character's profession windows once to fill it in. Switch off under Look > tooltips.
- Characters window (shift-click the minimap button): delete a character's saved data, and characters removed from your character list are spotted and cleaned up automatically.

## 0.8.10
- Crafts: also lists profitable recipes no character has learned yet (captured from each profession window you open). Turn off under Profit and prices. They are left out of shopping plans.

## 0.8.9
- Crafts: new Profession column you can sort by.
- Costs use the cheapest route (AH vs vendor, every alternate material), and materials on your alts count as owned.
- Shopping: the all-together total no longer double counts a bolt/bar and its raw materials.

## 0.8.8
- Shop top 10: picks the ten crafts that earn the most with your gold, splits your gold across them, and shows planned spend and each craft's cost.
- Shopping: your gold is shown at the bottom left; the Buy quantity follows the selected row.

## 0.8.7
- Shop top 10: each craft gets its own heading with its count (e.g. Spidersilk Boots x2), its materials underneath, and craftable materials broken into their raw materials, indented.
- Shop top 10: one shared gold budget across the list, so what you can afford adds up; crafts you can't afford are left out.

## 0.8.6
- Auction House: every Profiteer tab now fills the window, with the same height as the game's own tabs.
- Shopping: each item shows its lowest known price; lists scale to the window.
- Crafts: search box moved to the bottom right.
- Look: GreedUI no longer overrides an add-on's saved enabled state.

## 0.8.5
- Auction House: keep Blizzard's native Buy, Sell and Auctions tabs, remove Profiteer's redundant Auction House and Selling tabs, and fit the remaining Profiteer tabs beside the native tabs.
- Native auction handoff: open Blizzard's Sell tab and leave item selection and auction creation in the game UI. Profiteer's Selling tab is no longer available.
- Non-stackable items: classify duplicate copies as item auctions rather than commodity auctions.

## 0.8.4
- Shopping list: clicking a craft now lists every material that can itself be crafted both ways, the made item and its raw materials (copper bar and copper ore, a bolt of cloth and its cloth, and anything your characters have captured), so you can buy whichever is cheaper.

## 0.8.3
- "Buy up to" now stops at the gold you have on this character (turn off with "Limit Buy up to to the gold I have" in options), and the tooltip says when gold is the limit. Reagent lines in the tooltip show the price each as well as the total for the recipe (for example 2x Frilled Lichen 1g30s @ 65s each).

## 0.8.2
- New: window customization. Alt-click the minimap button to restyle each window separately (or all together): background textures, colors with copy/paste, opacity sliders, border styles, fonts, scale and position lock. Over 50 fonts to pick from (install the LookFonts folder for the bundled ones; SharedMedia fonts show up too). Off until you tick "Use a custom look"; unticking restores the original.
- Ledger fix: the Unrealized total counted a stack's price once instead of for every item in it (a 150-stack priced at 1s98c each counted as 1s98c, not 2g97s), so it came out far too low. Stacks are now priced per item times the quantity, and item names show correctly.
- Ledger fix: gold mailed between your own characters is now always recognized as a transfer (not income and not spending). It no longer depends on the game call that sets the gold, the receiving character now books it too, and gold already recorded as mail in and mail out is paired up and corrected once.
- Ledger fix: auction deposits are matched to the auctions being created, so a slow posting no longer shows up as "AH purchases".
- Ledger: new "Unrealized: listed, not sold yet" section. For each character it shows how many auctions you have up, their total asking price and an estimate after the AH cut, any sold items whose gold is still in the mail, and your biggest listings. It updates every time you open the auction house.
- Crafts: new "Buy up to" column and tooltip section. Walks each material up the AH price ladder from your last scan and tells you how many crafts you can buy materials for before the next one stops paying (and how much of each material, at what top price, and the total profit). Notes when the AH simply runs out of a material.
- Search: partial words and any word order now match, with the best name matches listed first.

## 0.8.1
- Ledger character dropdown now shows "Name - Realm", so same-named characters on different realms are told apart.

## 0.8.0
- New gold ledger: Profiteer now tracks every copper in and out, across all your characters, by source. Coming in: AH sales, returned deposits, vendor sales, quest rewards, looted coin, mail gold. Going out: AH deposits, the AH cut, AH purchases, vendor purchases, repairs, postage/COD, training, flights.
- Overhead and net profit are worked out for you (deposits kept after refunds + sale fees + repairs + flights + training).
- Also tracked: trades, bank slot purchases, gold mailed between your own characters and guild bank deposits/withdrawals (shown as "moved", not earned or spent), a best-sellers list from your sale invoices, gold on hand per character, gold per hour for the session, and a check that tells you if any change in your gold isn't explained by the ledger.
- The ledger is a tab in the Profiteer window (Crafts | Ledger): today / 7 days / 30 days / all time, per character or all, headline numbers, income and spending by source with percentages, an auction house breakdown (sales made, average sale, fees, deposits lost), overhead, best sellers, per character, per day, gold on hand and the cross-check. `/pf ledger [today|week|month|all]` opens it; `/pf ledger text` gives a copyable version; `/pf ledger reset` clears it.
- Ledger fixes: gold on hand no longer drops to 0 for characters you log out on; the headline is now "Net cash flow" with a "net before buying stock" line; unsold listings' deposits are shown as "not returned yet"; `/pf ledger log` lists the last recorded changes and what each was filed under.
- Search box on the Crafts tab: type part of a craft, material, profession or character name. Adding a new file: restart the game once.

## 0.7.9
- Items a vendor sells are now costed at the vendor price (even when an Auction House listing is cheaper, since vendor stock is unlimited) and are left out of the AH search when you click a craft. Vendor prices are learned whenever you open a vendor that sells the item in unlimited stock; the tooltip shows "Vendor buy price".

## 0.7.8
- Windows no longer bleed through each other: clicking a Profiteer window raises it, with its text and rows, above other addon windows (Baggie, etc.).

## 0.7.7
- Clicking a craft now searches for the finished item as well as its materials.

## 0.7.6
- The Profiteer window no longer closes when you click a craft to search the AH, so you can keep clicking down the list.

## 0.7.5
- Crafts that lose money are shown again (they were hidden because the minimum profit was 0). New "Hide money-losing" checkbox; `/pf minprofit` turns it on.

## 0.7.4
- Crafts with no AH price (nothing listed, reagent price missing) are no longer hidden: they show at the bottom of the list in grey with a "-" for profit, and the tooltip says why they are not ranked. The header counts priced and unpriced crafts.

## 0.7.3
- Release packaging: Wago upload fix.

## 0.7.2
- Release packaging fix: the Wago upload now runs from GitHub.

## 0.7.1
- The Profiteer window now opens beside the Auction House instead of on top of it, and can be dragged anywhere; it remembers where you put it (/pf ahbutton resets button and window).
- The AH "Profiteer" button drags more reliably (left or right button) and sits above the other AH widgets.

## 0.7.0
- Every craft now counts its materials both ways. A bar can be bought or smelted from ore, cloth bolts can be bought or made from cloth: whichever is cheaper is the cost used for the craft's profit, and the tooltip shows "or buy" with the ore/cloth prices and whether it beats the bar.
- Clicking a craft searches the AH for the bar and the ore (Handful of Copper Bolts: Copper Bar, Copper Ore), including crafts several steps deep (Bronze Bar: Copper Ore, Tin Ore).
- Works for any intermediate your characters' recipes make, plus a built-in list of the common bars and bolts.

## 0.6.3
- Fixed click-through searching for the wrong item name. Profiteer was saving a recipe's name as the item's name, so crafts that use smelted bars searched for "Smelt Copper" instead of "Copper Bar". It now uses the game's real item names everywhere, and repairs names saved by earlier versions on the first login.
- `/pf why` and `/pf track` still find a craft by its recipe name (for example "smelt copper").

## 0.6.2
- The TOC now carries the Wago project ID, so the Wago app recognizes a manually installed copy of Profiteer and offers updates for it.

## 0.6.1
- The addon now lists only Forever's interface numbers (16001 to 16003), so the addon list and Wago no longer show a Retail version.

## 0.6.0
- Work from a craft straight to its materials. In the results window: **click** a row to search the Auction House for that craft's materials, **shift-click** to search for the finished item, **right-click** to track it. Searches go to Auctionator's Shopping list when it is installed, otherwise to the Auction House's own search bar, otherwise to a copyable list of names.
- Tracked crafts are pinned to the top of the list with a gold `*` and ignore the minimum-profit and minimum-listings filters.
- New **Shop top 10** and **Shop tracked** buttons send the materials for several crafts at once.
- New `/pf shop [tracked]` and `/pf track <craft>` commands.

## 0.5.8
- `/pf top` and `/pf chars` now open in a copyable window too. `/pf top` lists the top 25 crafts with who can make each, cost, net sale price, profit, ROI, listings and sales per day.

## 0.5.7
- `/pf missing` and `/pf why <craft>` now open in a copyable window (Ctrl+C, scroll with the mouse wheel) instead of printing to chat.
- `/pf missing` also shows each skipped craft's material cost and vendor sell price where known, sorted alphabetically.

## 0.5.6
- New `/pf missing` command lists the crafts left out of the ranking for lack of prices, and why (nothing listed for the finished item, or which reagent has no price).
- Thin markets are easier to spot: a Listed count under 10 now shows in orange.

## 0.5.5
- Pressing Scan too soon after the last full scan no longer leaves the window waiting on a request Blizzard will ignore. It now says how long until the next scan is allowed. `/pf scan force` tries anyway.

## 0.5.4
- Reagent costs now ignore a lone lowball listing. If the cheapest listing is less than half the next-cheapest price, the reagent is costed at the reference price instead.
- Hover tooltips in the results window open on whichever side has room, so they no longer run off the edge of the screen.

## 0.5.3
- New `/pf why <craft>` command: shows how one craft's material cost and sale price were worked out, including every item option for each reagent. Useful for checking a number that looks wrong.

## 0.5.2
- Fixed prices being read per stack instead of per unit. Stacked items (cloth, herbs, ammo, bolts) were inflated by their stack size. Old price data is cleared automatically.
- Items with fewer than 3 units listed are now hidden by default, since a single listing is not a market price. Change it with `/pf minlisted <n>`.
- The results window now has a solid background, so nameplates and world text no longer show through the rows.

## 0.5.1 (first public beta)
- Ranks every craft your characters know by profit and ROI, using auction prices and vendor prices.
- Works across all characters on the account, with per-character "can craft now" counts from bags and bank.
- Automatic full Auction House scan when the AH opens, read out in small slices so the game never hitches.
- Price history, market median and trend, and estimated sales per day.
- Item tooltips with auction price, listings, median, trend and vendor price.
- Profiteer button on the Auction House window, plus a draggable minimap button.
- `/pf report` and `/pf errors` for diagnostics.
- Not included yet: buying and posting from inside the addon.
