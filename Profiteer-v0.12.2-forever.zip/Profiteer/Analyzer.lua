local ADDON, CP = ...

-- Cost of buying an item as-is: the vendor price when a vendor sells it, else the AH lowest buyout.
function CP:DirectCost(id)
  local p = self.db.prices[id]
  local ah = p and p.min
  -- A single lowball listing can't supply a real craft run. If the cheapest listing is
  -- less than half the next-cheapest price, cost the reagent at the reference price.
  if ah and p.ref and ah < p.ref * 0.5 then ah = p.ref end
  -- A vendor sells it in unlimited supply; still take the AH when it is cheaper.
  local v = self.db.vendor[id]
  if v and (not ah or v <= ah) then return v, "vendor" end
  if ah then return ah, "AH" end
  return nil
end

-- Cost of making one of an item from its materials (bar from ore, bolt from cloth ...),
-- each material costed the cheapest way. nil if any material has no price.
function CP:MakeCost(id, depth, seen)
  depth, seen = depth or 0, seen or {}
  if depth >= 4 or seen[id] then return nil end
  local plan = self:MakePlan(id)
  if not plan then return nil end
  seen[id] = true
  local total = 0
  for _, i in ipairs(plan.inputs) do
    local c
    for _, alt in ipairs(i.ids or { i.id }) do
      local ac = self:ReagentCost(alt, depth + 1, seen)
      if ac and (not c or ac < c) then c = ac end
    end
    if not c then seen[id] = nil return nil end
    total = total + c * i.count
  end
  seen[id] = nil
  return total / plan.yield
end

-- Reagent cost: the cheaper of buying it and making it from its materials.
-- Returns cost, source ("AH", "vendor" or "made"), as before.
function CP:ReagentCost(id, depth, seen)
  local c, src = self:DirectCost(id)
  local made = self:MakeCost(id, depth, seen)
  if made and (not c or made < c) then return made, "made" end
  return c, src
end

-- Price we expect to sell an item at. "safe" (default) uses the lower of the
-- current reference price and the two-week median, so a temporary spike can't
-- inflate a craft's profit. "current" uses today's reference price only.
function CP:SellPrice(id)
  local p = self.db.prices[id]
  local cur = p and p.ref
  if not cur then return nil end
  if self.db.settings.priceBasis == "current" then return cur end
  local st = CP.History.Stats(id)
  if st and st.median and st.samples >= 3 then return math.min(cur, st.median) end
  return cur
end

-- A reagent slot may accept several items (e.g. quality tiers): cost it with
-- the cheapest option. Returns cost per unit, source, and the item chosen.
function CP:SlotCost(rg)
  local best, bestSrc, bestID
  for _, id in ipairs(rg.ids or { rg.id }) do
    local c, src = self:ReagentCost(id)
    if c and (not best or c < best) then best, bestSrc, bestID = c, src, id end
  end
  return best, bestSrc, bestID or rg.id
end

function CP:Have(charKey, id)
  local inv = self.db.inventory[charKey]
  if not inv then return 0 end
  return (inv.bags and inv.bags[id] or 0) + (inv.bank and inv.bank[id] or 0)
end

-- How many of an item all your characters hold (bags + bank), from the last inventory scan of each
function CP:HaveAll(id)
  local n = 0
  for charKey in pairs(self.db.inventory or {}) do n = n + self:Have(charKey, id) end
  return n
end

function CP:HaveSlot(charKey, rg)
  local n = 0
  for _, id in ipairs(rg.ids or { rg.id }) do n = n + self:Have(charKey, id) end
  return n
end

function CP:CanMake(charKey, reagents)
  local best
  for _, rg in ipairs(reagents) do
    local n = math.floor(self:HaveSlot(charKey, rg) / rg.count)
    if not best or n < best then best = n end
  end
  return best or 0
end

-- The AH as a price ladder for one item: { {unit price, units}, ... } cheapest first, from the last scan.
function CP:Ladder(id)
  local l = self.db.listings and self.db.listings[id]
  if not l or type(l.sigs) ~= "table" then return nil end
  local out = {}
  for sig, e in pairs(l.sigs) do
    local count, total = tostring(sig):match("^(%d+)x(%d+)$")
    count, total = tonumber(count), tonumber(total)
    if count and total and count > 0 and e.c and e.c > 0 then
      out[#out + 1] = { total / count, count * e.c }
    end
  end
  if #out == 0 then return nil end
  table.sort(out, function(a, b) return a[1] < b[1] end)
  return out
end

-- How far can you keep buying the raw materials for a craft before it stops paying?
-- Walks each material up the AH price ladder one craft at a time; the craft stops when the next one's
-- materials cost more than it sells for (less your minimum profit). Materials a vendor sells never run out.
-- Returns { crafts, profit, cost, mats = { {id, units, worst} }, reason = "price"|"supply"|"gold"|"cap", limiter } or nil.
function CP:BuyDepth(g, budget, maxCrafts)
  if not g or g.unpriced or not g.revenue then return nil end
  local minProfit = self.db.settings.minProfit or 0
  local slots = {}
  local function addSlot(id, count)
    local slot = { id = id, count = count, units = 0, worst = 0, frac = 0, owned = self:HaveAll(id) }
    local c, src = self:DirectCost(id)
    if not c then return false end
    if src == "AH" then
      slot.ladder = self:Ladder(id)
      if not slot.ladder then return false end
      slot.i, slot.left = 1, slot.ladder[1][2]
    else
      slot.flat = c                       -- a vendor sells it: priced flat, never runs out
    end
    slots[#slots + 1] = slot
    return true
  end
  for _, rg in ipairs(g.reagents) do
    local c, src, id = self:SlotCost(rg)
    if not c then return nil end
    if src == "made" then
      -- bought as raw materials (ore for a bar, cloth for a bolt): walk the raw materials' price ladders
      for _, raw in ipairs(self:RawMaterials(id)) do
        if not addSlot(raw.id, raw.count * rg.count) then return nil end
      end
    elseif not addSlot(id, rg.count) then
      return nil
    end
  end
  local res = { crafts = 0, profit = 0, cost = 0, mats = slots, reason = "cap" }
  local function take(slot)
    -- take one unit, returns its price or nil when the AH has no more
    if slot.owned > 0 then slot.owned = slot.owned - 1 return 0 end
    if slot.flat then slot.units = slot.units + 1 slot.worst = slot.flat return slot.flat end
    while slot.left <= 0 do
      slot.i = slot.i + 1
      local nxt = slot.ladder[slot.i]
      if not nxt then return nil end
      slot.left = nxt[2]
    end
    slot.left = slot.left - 1
    local p = slot.ladder[slot.i][1]
    slot.units = slot.units + 1
    if p > slot.worst then slot.worst = p end
    return p
  end
  for _ = 1, maxCrafts or 2000 do
    local before = {}
    for i, sl in ipairs(slots) do before[i] = { sl.units, sl.worst, sl.i, sl.left, sl.frac, sl.owned } end
    local marginal, short = 0, nil
    for _, sl in ipairs(slots) do
      sl.frac = sl.frac + sl.count
      local need = math.floor(sl.frac + 1e-9)
      sl.frac = sl.frac - need
      for _ = 1, need do
        local p = take(sl)
        if not p then short = sl break end
        marginal = marginal + p
      end
      if short then break end
    end
    if short then
      for i, sl in ipairs(slots) do sl.units, sl.worst, sl.i, sl.left, sl.frac, sl.owned = before[i][1], before[i][2], before[i][3], before[i][4], before[i][5], before[i][6] end
      res.reason, res.limiter = "supply", short.id
      break
    end
    if g.revenue - marginal < minProfit or g.revenue - marginal <= 0 then
      for i, sl in ipairs(slots) do sl.units, sl.worst, sl.i, sl.left, sl.frac, sl.owned = before[i][1], before[i][2], before[i][3], before[i][4], before[i][5], before[i][6] end
      res.reason = "price"
      break
    end
    if self.db.settings.limitByGold ~= false and GetMoney and res.cost + marginal > (budget or GetMoney()) then
      for i, sl in ipairs(slots) do sl.units, sl.worst, sl.i, sl.left, sl.frac, sl.owned = before[i][1], before[i][2], before[i][3], before[i][4], before[i][5], before[i][6] end
      res.reason = "gold"
      break
    end
    res.crafts = res.crafts + 1
    res.cost = res.cost + marginal
    res.profit = res.profit + (g.revenue - marginal)
  end
  return res
end

local SORTERS = {
  name   = function(g) return g.name:lower() end,
  cost   = function(g) return g.cost end,
  revenue = function(g) return g.revenue end,
  profit = function(g) return g.profit end,
  ratio  = function(g) return g.ratio end,
  listed = function(g) return g.listed end,
  make   = function(g) return g.best end,
  perday = function(g) return g.perDay or -1 end,
  prof   = function(g) return tostring(g.prof or ""):lower() end,
  crafters = function(g)
    local k = g.chars and g.chars[1]
    return k and tostring(CP.ShortName(k)):lower() or ""
  end,
  depth = function(g)
    if g.depth == nil then
      local ok, d = pcall(CP.BuyDepth, CP, g)
      g.depth = ok and d or false
    end
    return g.depth and g.depth.crafts or -1
  end,
}

-- Vendor sell price of an item if the client already knows it
local function VendorSell(id)
  local fn = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  if not fn then return nil end
  local ok, _, _, _, _, _, _, _, _, _, _, sell = pcall(fn, id)
  if ok and type(sell) == "number" and sell > 0 then return sell end
  return nil
end

-- Returns results (sorted, filtered), skippedCount, totalDistinctCrafts
function CP:BuildResults()
  local db, s = self.db, self.db.settings
  self:IndexMakers()

  -- Group identical crafts known by several characters into one row
  local groups, order = {}, {}
  for charKey, profs in pairs(db.recipes) do
    for prof, recs in pairs(profs) do
      for _, r in ipairs(recs) do
        local key = prof .. ":" .. r.id
        local g = groups[key]
        if not g then
          g = { key = key, prof = prof, id = r.id, name = r.name, yield = r.yield,
                reagents = r.reagents, chars = {}, make = {}, diffs = {} }
          groups[key] = g
          order[#order + 1] = g
        end
        g.chars[#g.chars + 1] = charKey
        g.diffs[charKey] = r.diff
      end
    end
  end

  -- recipes the profession windows listed but nobody has learned (needs showUnlearned)
  if s.showUnlearned ~= false then
    for charKey, profs in pairs(db.unlearned or {}) do
      for prof, recs in pairs(profs) do
        for _, r in ipairs(recs) do
          local key = prof .. ":" .. r.id
          local g = groups[key]
          if not g then
            g = { key = key, prof = prof, id = r.id, name = r.name, rname = r.rname, yield = r.yield,
                  reagents = r.reagents, chars = {}, make = {}, diffs = {}, notLearned = true, learnable = {} }
            groups[key] = g
            order[#order + 1] = g
          end
          if g.notLearned then g.learnable[#g.learnable + 1] = charKey end
        end
      end
    end
  end

  local results, skipped = {}, 0
  self.skippedList = {}
  self.unpriced = {}
  for _, g in ipairs(order) do
   if not (s.learnedOnly ~= false and g.notLearned) then   -- "Learned recipes only" ticked: hide crafts nobody has learned
    local p = db.prices[g.id]
    local sell = self:SellPrice(g.id)
    local cost, missing, missingName = 0, false, nil
    for _, rg in ipairs(g.reagents) do
      local c, _, cid = self:SlotCost(rg)
      if not c then missing = true; missingName = CP.ItemName(cid or rg.id); break end
      cost = cost + c * rg.count
    end

    if not sell or missing or cost <= 0 then
      skipped = skipped + 1
      local why
      if not sell then
        why = (p and (p.n or 0) == 0) and "nothing listed on the AH for the finished item" or "finished item not seen in a scan"
      elseif missing then
        why = "no price for reagent " .. tostring(missingName)
      else
        why = "material cost works out to zero"
      end
      local extra = ""
      if not missing and cost > 0 then
        extra = " | materials " .. CP.MoneyPlain(cost)
        if g.yield and g.yield > 1 then extra = extra .. " (makes " .. g.yield .. ")" end
      end
      local vs = VendorSell(g.id)
      if vs then extra = extra .. " | vendor sell " .. CP.MoneyPlain(vs) .. " each" end
      self.skippedList[#self.skippedList + 1] = g.name .. " (" .. g.prof .. "): " .. why .. extra

      -- still show the craft in the window (below the priced ones), so every craft you know is visible
      g.unpriced, g.why = true, why
      g.cost = (not missing and cost > 0) and cost or nil
      g.sell = sell
      g.listed = p and p.qty or 0
      local st = CP.History.Stats(g.id)
      g.perDay = st and st.perDay
      g.best = 0
      for _, charKey in ipairs(g.chars) do
        local n = self:CanMake(charKey, g.reagents)
        g.make[charKey] = n
        if n > g.best then g.best = n end
      end
      g.tracked = (s.tracked and s.tracked[g.key]) and true or false
      if not s.craftableOnly or g.best > 0 then
        self.unpriced[#self.unpriced + 1] = g
      end
    else
      g.cost = cost
      g.sell = sell
      g.revenue = sell * g.yield * (1 - s.ahCut)
      g.profit = g.revenue - cost
      g.ratio = g.profit / cost
      g.listed = p.qty or 0
      local st = CP.History.Stats(g.id)
      g.perDay = st and st.perDay

      g.best = 0
      for _, charKey in ipairs(g.chars) do
        local n = self:CanMake(charKey, g.reagents)
        g.make[charKey] = n
        if n > g.best then g.best = n end
      end

      g.tracked = (s.tracked and s.tracked[g.key]) and true or false
      local keep = (not s.hideLosses or g.profit >= s.minProfit)
        and g.listed >= s.minListed
        and (not s.craftableOnly or g.best > 0)
        and (s.minSales <= 0 or not g.perDay or g.perDay >= s.minSales)
      if keep or g.tracked then results[#results + 1] = g end
    end
   end
  end

  table.sort(self.skippedList)
  local keyFn = SORTERS[s.sortKey] or SORTERS.ratio
  local desc = s.sortDesc
  table.sort(results, function(a, b)
    if a.tracked ~= b.tracked then return a.tracked end   -- tracked crafts pinned on top
    local x, y = keyFn(a), keyFn(b)
    if x == y then return a.name < b.name end
    if desc then return x > y end
    return x < y
  end)

  table.sort(self.unpriced, function(x, y)
    if x.tracked ~= y.tracked then return x.tracked end
    if (x.best > 0) ~= (y.best > 0) then return x.best > 0 end
    return x.name < y.name
  end)
  return results, skipped, #order
end

function CP:Refresh()
  if self.UI and self.UI.Rebuild then self.UI.Rebuild() end
end
